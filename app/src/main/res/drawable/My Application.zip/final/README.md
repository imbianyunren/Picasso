"# Picasso" 
